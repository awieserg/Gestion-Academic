import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const checkSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          if (error.message.includes('refresh_token_not_found')) {
            localStorage.clear();
            window.location.href = '/';
            return;
          }
          throw error;
        }

        if (mounted) {
          setUser(session?.user ?? null);
          setLoading(false);
        }
      } catch (error) {
        console.error('Error checking session:', error);
        if (mounted) {
          setLoading(false);
          setUser(null);
        }
      }
    };

    checkSession();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (mounted) {
        if (event === 'SIGNED_OUT') {
          localStorage.clear();
          setUser(null);
        } else {
          setUser(session?.user ?? null);
        }
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        switch (error.message) {
          case 'Invalid login credentials':
            throw new Error('Email ou mot de passe incorrect');
          case 'Email not confirmed':
            throw new Error('Veuillez confirmer votre email avant de vous connecter');
          default:
            throw new Error('Une erreur est survenue lors de la connexion');
        }
      }

      return data;
    } catch (error) {
      throw error;
    }
  };

  const signUp = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) {
        switch (error.message) {
          case 'User already registered':
            throw new Error('Un compte existe déjà avec cet email');
          case 'Password should be at least 6 characters':
            throw new Error('Le mot de passe doit contenir au moins 6 caractères');
          default:
            throw new Error("Une erreur est survenue lors de l'inscription");
        }
      }

      if (data.user) {
        const { error: profileError } = await supabase.from('users').insert({
          id: data.user.id,
          email: data.user.email,
          role: 'ADMIN',
          created_at: new Date().toISOString(),
        });

        if (profileError) {
          console.error('Error creating user profile:', profileError);
        }
      }

      return data;
    } catch (error) {
      throw error;
    }
  };

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      localStorage.clear();
    } catch (error) {
      console.error('Error signing out:', error);
      throw new Error('Une erreur est survenue lors de la déconnexion');
    }
  };

  return {
    user,
    loading,
    signIn,
    signUp,
    signOut,
  };
}